"""Version of the Client that is used in User-Agent header."""

VERSION = '1.36.1'
